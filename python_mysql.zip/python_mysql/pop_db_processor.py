import os
import sys
import pymysql
import csv
import logging
import decimal
import webbrowser
from ConfigParser import SafeConfigParser


#############################################
    
    #queries for database

#############################################

query_insert = '''
        YOUR_INSERT_QUERY_HERE
    '''

query_select = '''
        YOUR_SELECT_QUERY_HERE
    '''



#############################################
    
    #functions used in main

#############################################

def select_query(connection, query):
    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()
        return result
        
def execute_insert_query(connection, query, rows):
    insert_successful = []
    with connection.cursor() as cursor:  
        try:
            for row in rows:
                cursor.execute(query, row)
                insert_successful.append(1)
        except:
            logging.error('Could not insert your insert statement. - Values:' + str(row))
            sys.exit("Something went wrong. Check log for more info.")
            

    connection.commit()
    cursor.close()
    logging.info('Insert SQL statement was successful - ' + str(len(rows)) + ' rows were inserted')
    
    
#############################################
    
    #MAIN

#############################################

def main(filename):
    
    #create logging file
    logging.basicConfig(filename='popdb.log',level=logging.DEBUG, format="%(levelname) -10s %(asctime)s %(module)s:%(lineno)s %(funcName)s %(message)s")
    
    
    #read config file to get database information
    config = SafeConfigParser()
    config.read('config.ini')
    hostname = config.get('database', 'HOSTNAME').strip("'") 
    username = config.get('database', 'USERNAME').strip("'") 
    password = config.get('database', 'PASSWORD').strip("'") 
    database = config.get('database', 'DATABASE').strip("'") 
    
    try:
        #Connect to the database
        connection = pymysql.connect(host=hostname,
                             user=username,
                             password=password,
                             db=database,
                             cursorclass=pymysql.cursors.DictCursor
                             )
        
    except:
        sys.exit("Database connection was not successful. Check your database configs.")
        logging.error('Database connection was not successful. Database connection was not successful. Check your database configs.')
    
    
    
    #open csv file
    with open(filename, 'rb') as csvfile:
        print 'Now processing ' + filename
        reader = csv.reader(csvfile, delimiter=',')
        
        #important
        #convert strings from csv to integers/SQLdecimal
        rows = [[int(row[0]), int(row[1]), decimal.Decimal(row[2])] for row in reader]
        
        
        execute_insert_query(connection, query_insert, rows)
        print 'Data inserted into tables'
            
    #close csv_file
    csvfile.close()
    
    #get calculations from database
    values = select_query(connection, query_select)
    
    body = open('html/start.html', 'r').read()
    for key, value in values.items():
        print str(key) + ' ' + str(value)
        
        body += '''
            <div class="well">
                <h4>''' + str(key) + '''</h4>
                <p>''' + str(value) +'''</p> 
            </div>
        '''
    body += open('html/end.html', 'r').read()
    
    report = open('html/report.html', 'w')
    report.write(body)
    
    #close cursor and connection to database
    connection.close()
    
    
    print 'All done.'
    print 'HTML file is ready!'
    
    #open report.html and show calculations
    html_file = 'html/report.html'
    webbrowser.open('file://' + os.path.realpath(html_file))
    
    

#############################################
    
    #Run MAIN

#############################################
if __name__ == "__main__":
    filename = sys.argv[1]
    main(filename)


